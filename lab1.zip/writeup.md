## Task 1
I used Python's HTTP server class to host a simple local web server running at http://localhost:8000/,
that simply printed "My server is up."


## Task 2
Q: Explain how an eavesdropper can "sniff" web traffic between a client and HTTP server to see what is being communicated (including which resources are being fetched and the contents of the resources):
A: HTTP is not secure because the data it transfers across the network is not encryted,
so anyone could listen in on the network, using an application such as Wireshark, and easily see what
data is contained in a packet.
In Wireshark, you can click on a packet ![alt text](image.png) and see the raw bytes 
(which can also be viewed as raw text) for the information that is transferred over the network.![alt text](image-1.png). In HTTP, an eavesdropper can see the full URL and the source and destination IP addresses,
in addition to the unencrypted packet data, which means this web traffic is not secure.

## Task 3
How I made an SSL certification:
openssl req -x509 -out localhost.crt -keyout localhost.key \
  -newkey rsa:2048 -nodes -sha256 \
  -subj '/CN=localhost' -extensions EXT -config <( \
   printf "[dn]\nCN=localhost\n[req]\ndistinguished_name = dn\n[EXT]\nsubjectAltName=DNS:localhost\nkeyUsage=digitalSignature\nextendedKeyUsage=serverAuth")

I then added this certificate to my System certificates. 
I created an HTTPS server using the SSL module to encrypt traffic and handle
the TLS handshake (it uses the certificate so my client, i.e. the browser,
knows to trust the server, i.e. the localhost).

Q: Why can't you obtain an SSL certificate for your local web server from a certificate authority? 
A: Certificate authorities can’t provide certificates for my local web server, because it uses the domain name
"localhost." This name is available to everyone to use, which means that no one can own "localhost",
so there is no way to give a certificate to someone to verify that they own "localhost". 
Source https://letsencrypt.org/docs/certificates-for-localhost/

Q: Comment on the difference between the contents of the HTTP and HTTPS traffic
A: HTTPS traffic also includes the TLS protocol and HTTP, (instead of just TCP and HTTP protocols for HTTP), 
and additional information about the Cipher Spec.
You can still see the source and destination IP addresses, the length/size of each packet,
information about the three-way handshake, but you cannot see the URL or the message data
(because it appears in its encrypted form):
![alt text](image-2.png)
